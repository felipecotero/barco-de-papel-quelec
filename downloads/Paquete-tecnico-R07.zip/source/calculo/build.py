import sys,json,math,csv,shutil,itertools
from pathlib import Path
sys.path.insert(0,'/private/tmp/barco-libs')
import numpy as np
from shapely.geometry import Polygon,LineString,Point,box
from shapely.ops import split,unary_union
from shapely import affinity
ROOT=Path.cwd();OUT=ROOT/'output/blueprints-barco-r07';APP=ROOT/'output/barco-r07'
for n in ['source','tablas','cad','plantillas']:(OUT/n).mkdir(parents=True,exist_ok=True)
base=json.loads((ROOT/'output/barco-taller/model-r05.json').read_text());data=json.loads(json.dumps(base));old={p['id']:p for p in base['parts']};parts=[];recs={};PP={};sheets=json.loads((ROOT/'output/blueprints-barco-r06/source/nesting-r06.json').read_text());FY=base['floorY'];DAT=base['datum'];H=2-FY;W=.9983505;DEP=.270;k=(DEP/2-.004)/(1-(.9375*DEP/2-FY)/H)
def clean(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,(np.integer,np.floating)):return x.item()
 if isinstance(x,dict):return {k:clean(v)for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v)for v in x]
 return x

def write(name,headers,rows):
 with (OUT/'tablas'/name).open('w')as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(clean(rows))
def polygons(g):return [g]if g.geom_type=='Polygon'else [a for a in g.geoms if a.geom_type=='Polygon'and a.area>.001]
def rings(g):return [list(g.exterior.coords)[:-1],*[list(r.coords)[:-1]for r in g.interiors]]
S=np.array(base['seam']);
def cut(y,z):
 d=(S[:,1]-y)**2+(S[:,2]-z)**2
 if min(d)<1e-10:return S[d.argmin(),0]
 a=1/(.0001+d)**2;return np.dot(S[:,0],a)/sum(a)
def develop(sg):
 C=np.array([0,FY,sg*(.002+k)]);A=np.array([0,1,-sg*k/H]);A/=np.linalg.norm(A)
 E={}
 for side in [-1,1]:
  r=np.array([side*W,FY,sg*.002])-C;r-=A*np.dot(r,A);E[side]=r/np.linalg.norm(r)
 return {'C':C,'A':A,'Eminus':E[-1],'Eplus':E[1],'sg':sg}
def forward(x,y,sg):
 skin=.002;yc=.9375*(skin+k*(1+FY/H-abs(x)/W))/(1+.9375*k/H);y=max(y,yc)
 return np.array([x,y,sg*(skin+k*max(0,1-(y-FY)/H-abs(x)/W))])
def uvpoint(P,d):
 r=P-d['C'];v=np.dot(r,d['A']);u=np.linalg.norm(r-v*d['A'])*(-1 if P[0]<0 else 1);return np.array([u,v])*1000

def world(uv,d):
 u,v=np.array(uv)/1000;return d['C']+d['A']*v+(d['Eminus']if u<0 else d['Eplus'])*abs(u)
def midnormal(uv,d):
 side=-1 if uv[0]<0 else 1;n=np.cross(side*(d['Eminus']if side<0 else d['Eplus']),d['A']);return n/np.linalg.norm(n)
def crease_poly(poly):
 res=[]
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):
  res.append(a)
  if a[0]*b[0]<-1e-12:res.append(a+(b-a)*(-a[0])/(b[0]-a[0]))
 return res
# Hull and floor retain all R06 contours and holes. J01-J04 retain the compensated auxiliary reliefs.
for p in base['parts']:
 if p['id'].startswith('V'):continue
 p=json.loads(json.dumps(p));parts.append(p);g=unary_union([Polygon(a[0],a[1:])for a in p['whole']]);PP[p['id']]=g;recs[p['id']]=[('CORTE',r,True)for a in polygons(g)for r in rings(a)]+[('CORTE_ESCENICO',a,False)for a in p['seams']]
# Folded skins: exact orthonormal development of both facets, not their XY projection.
DEV={};SKIN={};JOINT={}
for sg,code,bound in [(1,'V01',1.0),(-1,'V02',1.2)]:
 d=develop(sg);DEV[code]=d;full=[]
 for suff in ['A','B']:
  src=old[code+suff];xy=np.array(src['uv'])/1000+np.array(src['origin'][:2]);xy=crease_poly(xy);uv=np.array([uvpoint(forward(x,y,sg),d)for x,y in xy]);g=Polygon(uv).buffer(0);full.append(g);pid=code+suff
  p={**src,'origin':[0,0,0],'u':[1,0,0],'v':[0,1,0],'uv':list(g.exterior.coords)[:-1],'whole':[rings(g)],'development':clean(d),'area':g.area/1e6,'seams':[],'chunks':[]};parts.append(p);SKIN[pid]=g;PP[pid]=g;recs[pid]=[('CORTE',list(g.exterior.coords)[:-1],True)]
  seg=g.intersection(LineString([(0,-200),(0,3000)]))
  if seg.geom_type=='LineString':recs[pid].append(('PLIEGUE_UNA_PIEL',list(seg.coords),False))
 # Four separate seam bands, one per facet, inclined exactly as the skin.
 hw=W*(1-(bound-FY)/H);joint=[uvpoint(forward(x,bound,sg),d)for x in [-hw,0,hw]];JOINT[code]=joint
 for si,suf in [(0,'L'),(1,'R')]:
  band=LineString(joint[si:si+2]).buffer(30,cap_style=2).intersection(unary_union(full).convex_hull);band=band.intersection(box(-3000,-3000,0,3000)if si==0 else box(0,-3000,3000,3000));pid='JV'+code[-1]+suf
  p={'id':pid,'board':0,'stockAngle':0,'stockOrigin':[0,0],'origin':[0,0,0],'u':[1,0,0],'v':[0,1,0],'uv':list(band.exterior.coords)[:-1],'whole':[rings(band)],'chunks':[],'seams':[],'area':band.area/1e6,'development':{**clean(d),'innerOffsetMm':4}};parts.append(p);PP[pid]=band;recs[pid]=[('CORTE',list(band.exterior.coords)[:-1],True)]
# Actual cylinder/skin intersection: tube mostly inside the hollow sail, not a full-height planar slot.
for p in parts:
 if not p.get('development'):continue
 d={a:np.array(v)if a in ['C','A','Eminus','Eplus']else v for a,v in p['development'].items()};g=PP[p['id']]
 for side in [-1,1]:
  if side<0 and base['tube']['x']-.01625>0:continue
  n=midnormal([side,0],d);const=np.dot(n,d['C']);ellipse=[]
  for a in np.linspace(0,2*math.pi,361)[:-1]:
   x=base['tube']['x']+.01625*math.cos(a);z=base['tube']['z']+.01625*math.sin(a);y=(const-n[0]*x-n[2]*z)/n[1];ellipse.append(uvpoint(np.array([x,y,z]),d))
  hole=Polygon(ellipse).intersection(box(-3000,-3000,0,3000)if side<0 else box(0,-3000,3000,3000));g=g.difference(hole)
 # Combined principal bar and crossmember slots are a projected union, one contour per skin.
 for b in base['bars']:
  # vertical-axis projection is not used here: each through-bar runs in Z (width).
  for m in [None]:
   samples=[]
   for a in np.linspace(0,2*math.pi,97)[:-1]:
    xx=b['x']+.021*math.cos(a);yy=b['y']+.021*math.sin(a);samples.append(uvpoint(forward(xx,yy,d['sg']),d))
   g=g.difference(Polygon(samples))
 # Scenic line follows the original implicit field on the new faces.
 seam=[]
 for y in np.linspace(FY,2,1001):
  hw=W*(1-(y-FY)/H);lo,hi=-hw,hw
  for _ in range(40):
   x=(lo+hi)/2;z=forward(x,y,d['sg'])[2]
   if x<cut(y,z):lo=x
   else:hi=x
  pt=forward((lo+hi)/2,y,d['sg']);seam.append(uvpoint(pt,d))
 line=LineString(seam);sections=polygons(g)
 ext=list(line.coords);a=np.array(ext[0]);b=np.array(ext[1]);ext[0]=(a+(a-b)/np.linalg.norm(a-b)*200).tolist();a=np.array(ext[-1]);b=np.array(ext[-2]);ext[-1]=(a+(a-b)/np.linalg.norm(a-b)*200).tolist()
 try:sections=sum([polygons(split(q,LineString(ext)))for q in sections],[])
 except ValueError:pass
 p['whole']=[rings(a)for a in polygons(g)];p['chunks']=[]
 for q in sections:
  pt=world(q.representative_point().coords[0],d);p['chunks'].append({'side':-1 if pt[0]<cut(pt[1],pt[2])else 1,'rings':rings(q)})
 intersect=line.intersection(g);p['seams']=[list(a.coords)for a in ([intersect]if intersect.geom_type=='LineString'else getattr(intersect,'geoms',[]))if a.geom_type=='LineString']
 PP[p['id']]=g;recs[p['id']]=[('CORTE',r,True)for q in polygons(g)for r in rings(q)]+[('CORTE_ESCENICO',l,False)for l in p['seams']]+[r for r in recs[p['id']]if r[0]=='PLIEGUE_UNA_PIEL']
# Ribs are net frames; flutes are vertical along their long dimension.
ribH=H*(1-.28/W);rb=k*(1-.28/W);t=.04;rhs=rb-t*math.sqrt(1+(rb/ribH)**2);ib=rhs-rb/ribH*t;it=rhs/(rb/ribH)
for sg,code in [(-1,'CA'),(1,'CB')]:
 g=Polygon([[-rb*1000,0],[rb*1000,0],[0,ribH*1000]],[[[-ib*1000,40],[0,it*1000],[ib*1000,40]]])
 for m in base['members']:
  a,b=np.array(m['a']),np.array(m['b']);x=sg*.28
  if (a[0]-x)*(b[0]-x)>0 or abs(b[0]-a[0])<1e-8:continue
  q=a+(b-a)*(x-a[0])/(b[0]-a[0]);yy=(q[1]-FY)*1000;zz=q[2]*1000
  if yy<45:g=g.difference(box(zz-13,-1,zz+13,yy+13))
 PP[code]=g;recs[code]=[('CORTE',r,True)for r in rings(g)]
# Every PP auxiliary blank is counted and placed, not hidden in an allowance.
# 16 hull/base tabs, 12 rib/skin tabs, 12 closure carriers. Contraplates at each mechanical foot.
for prefix,count,w,h in [('TP',28,120,30),('VC',12,120,30),('CP',68,60,30)]:
 for i in range(count):
  code=f'{prefix}{i+1:02}';g=box(0,0,w,h);PP[code]=g;recs[code]=[('CORTE',list(g.exterior.coords)[:-1],True)]
  if prefix!='CP':recs[code].append(('PLIEGUE',[(60,0),(60,30)],False))
  else:
   for xx in [15,45]:recs[code].append(('TALADRO_6_2',[(xx+3.1*math.cos(a),15+3.1*math.sin(a))for a in np.linspace(0,2*math.pi,49)[:-1]],True))
# Keep exact old hull placement; test true folded sail blanks in their previous locations.
BLANK={p['id']:Polygon(p['uv'])for p in parts}
for code,g in PP.items():
 if code not in BLANK:BLANK[code]=g
placements=[];occupied=[[]for _ in range(6)]
def tr(g,ang,xy):
 q=affinity.rotate(g,ang,origin=(0,0));mi=q.bounds[:2];return affinity.translate(q,xy[0]-mi[0],xy[1]-mi[1])
def valid(q,s):return q.bounds[0]>=10-1e-6 and q.bounds[1]>=10-1e-6 and q.bounds[2]<=2430+1e-6 and q.bounds[3]<=1210+1e-6 and all(q.distance(a)>=6-1e-6 for _,a in occupied[s])
unplaced=[]
for si,sheet in enumerate(sheets):
 for code,ang,xy in sorted(sheet,key=lambda r:0 if r[0].startswith('V') else 1):
  if code=='V02B':xy=[1580,60]
  if code=='B01':xy=[10,945]
  if code.startswith('H') and code.endswith('B'):unplaced.append(code);continue
  q=tr(BLANK[code],ang,xy)
  if not valid(q,si):print('initial reject',code,q.bounds,[(c,q.distance(a)) for c,a in occupied[si]],flush=True)
  if valid(q,si):placements.append([code,si,ang,xy]);occupied[si].append((code,q))
  else:unplaced.append(code)
# Deterministic bottom-left search, with contact-derived positions and a 10mm supplemental grid.
rest=unplaced+[c for c in BLANK if c not in {r[0]for s in sheets for r in s}]
rest.sort(key=lambda c:(0 if c.startswith('V') else 1,-max(BLANK[c].bounds[2]-BLANK[c].bounds[0],BLANK[c].bounds[3]-BLANK[c].bounds[1])))
CACHE=json.loads((ROOT/'tmp/pdfs/barco-r07/placement-cache.json').read_text())
for code in rest:
 found=None;g=BLANK[code]
 if code in CACHE:
  si,ang,xy=CACHE[code];q=tr(g,ang,xy)
  if valid(q,si):
   placements.append([code,si,ang,xy]);occupied[si].append((code,q));continue
 for si in range(6):
  for ang in [0,90,180,270]:
   zero=tr(g,ang,[0,0]);bw,bh=zero.bounds[2:];xs={10.};ys={10.}
   for _,a in occupied[si]:
    x0,y0,x1,y1=a.bounds;xs.update([x1+6,x0-bw-6]);ys.update([y1+6,y0-bh-6])
   xs.update(np.arange(10,2430-bw+.01,20));ys.update(np.arange(10,1210-bh+.01,20))
   for y in sorted(y for y in ys if 10<=y<=1210-bh+1e-6):
    for x in sorted(x for x in xs if 10<=x<=2430-bw+1e-6):
     q=affinity.translate(zero,x,y)
     if valid(q,si):found=[code,si,ang,[float(x),float(y)]];occupied[si].append((code,q));break
    if found:break
   if found:break
  if found:break
 if not found:raise RuntimeError('No cabe '+code)
 placements.append(found)
 print('placed',code,found[1:],flush=True)
# audit geometric nesting, not bounding rectangles; inside a rib window is legitimate reclaim.
minimum=min(a.distance(b)for sheet in occupied for (_,a),(_,b)in itertools.combinations(sheet,2));assert minimum>=6-1e-6
lookup={c:(s,a,xy)for c,s,a,xy in placements}
for p in parts:
 si,a,xy=lookup[p['id']];q=affinity.rotate(Polygon(p['uv']),a,origin=(0,0));p['board']=si;p['stockAngle']=a;p['stockOrigin']=[xy[0]-q.bounds[0],xy[1]-q.bounds[1]]
# Move sail columns onto centreline, add their short skin arms and the B-only flag spine.
for m in data['members']:
 if m['id'].endswith(('P10','P12')):
  m['a'][2]=0;m['b'][2]=0
newmembers=[]
for a in data['anchors']:
 if a['kind']!='vela':continue
 x,_,z=a['center'];rawx=x/1000;rawy=z/1000+DAT;target=forward(rawx,rawy,1);target[2]-=.002
 newmembers.append({'id':a['id']+'-BRAZO','kind':'angleSkin','side':-1 if rawx<0 else 1,'a':[rawx,rawy,.0075],'b':target.tolist(),'s_mm':20,'L_mm':abs(target[2]-.0075)*1000,'mass_kg':abs(target[2]-.0075)*(.02*.0015*2-.0015**2)*2700})
 a.update(center=[target[0]*1000,target[2]*1000,(target[1]-DAT)*1000],sleeve_L_mm=5.5,nylon_screw='M4x16')
# Fixed mast support at x280, two brackets at y550/1100, all B.
for pid,a,b in [('B-P17',[.28,FY+.0075,-.061],[.28,FY+.0075,.061]),('B-P18',[.28,FY+.0075,0],[.28,1.11,0])]:
 L=np.linalg.norm(np.array(b)-a);newmembers.append({'id':pid,'kind':'flagSpine','side':1,'a':a,'b':b,'s_mm':15,'L_mm':L*1000,'mass_kg':L*(.015**2-.013**2)*2700})
for i,y in enumerate([.55,1.1]):
 a=[.28,y,0];b=[data['tube']['x'],y,data['tube']['z']];L=np.linalg.norm(np.array(b)-a);newmembers.append({'id':f'B-T0{i+1}','kind':'angleSkin','side':1,'a':a,'b':b,'s_mm':20,'L_mm':L*1000,'mass_kg':L*(.02*.0015*2-.0015**2)*2700})
data['tube'].update(outerMm=32,innerMm=30,material='Al6063-T6',insertionGuideMm=[30,22,20]);data['members']+=newmembers;data['parts']=parts;data.update(revision='R07',massLimitKg=14,formStudy={'id':'R07','baseDepthMm':270,'status':'Presupuesto y despiece R07; prototipo pendiente','faces':4,'closures':6,'closureContactMm':[20,15],'ribsXmm':[-280,280],'massValidated':False,'stockValidated':True})
# All PP measured as nominal blanks; cutout savings are deliberately not deducted.
ppareas={c:g.area/1e6 for c,g in BLANK.items()};pparea=sum(ppareas.values());oldbudget=list(csv.DictReader((ROOT/'output/blueprints-barco-r06/tablas/presupuesto-masa-kg.csv').open()))
BUDGET=[]
for r in oldbudget:
 name=r['partida'];v=float(r['kg'])
 if name.startswith(('TOTAL','Margen'))or name in ['Piel de casco','Fondo plano','Dos capas de vela','Cuatro bandas sin descontar recortes','56 kits de fijación nylon / máximo','Rearme escénico independiente / límite']:continue
 if name.startswith('Tubo T01'):
  name='T01 Al Ø32x1 / ID30 / 1603,32 mm';v=math.pi/4*(.032**2-.030**2)*(base['tube']['top']-base['tube']['bottom'])*2700
 if 'Repartos, brazos' in name:
  name='Brazos casco, placas, apoyos y protección R06 / límite';v=.500
 BUDGET.append([name,v,'límite'if'calculados'not in name and'Barras Al'not in name and'Tubo T01'not in name else 'teórico'])
BUDGET.insert(0,['Todo PP instalado: paños, bandas, costillas, 40 pestañas y 68 contraplacas',pparea*.600,'blancos nominales a 600 g/m²'])
BUDGET.extend([['56 kits de bandas casco R06',.122,'límite'],['Nuevos kits nylon: bandas vela, pestañas y cierres',.440,'límite'],['6 parejas velcro, fundas textiles y retención',.080,'límite'],['4 uniones costilla a bastidor y fijación metálica',.120,'límite'],['Nuevos perfiles y brazos Al para vela y bandera',sum(m['mass_kg']for m in newmembers),'teórico'],['2 abrazaderas T01 y tornillería al brazo',.080,'límite'],['Adhesivo PP-LSE instalado / fondo y encuentros',.060,'límite, curado según ficha']])
MASS=sum(r[1]for r in BUDGET);MARGIN=14-MASS;data.update(mass=MASS,margin=MARGIN);assert MARGIN>0,(MASS,MARGIN)
write('presupuesto-masa-kg.csv',['partida','kg','criterio'],BUDGET+[['TOTAL R07',MASS,'presupuesto, no pesaje'],['Límite terminado',14,'autorizado'],['Margen',MARGIN,'disponible']])
write('compra-y-anidado.csv',['pieza','lamina','rotacion_grados','u_min_mm','v_min_mm'],[[c,s+1,a,*xy]for c,s,a,xy in placements]);write('areas-PP.csv',['pieza','area_blanco_m2','masa_600g_kg'],[[c,a,a*.6]for c,a in ppareas.items()]);write('perfiles-bastidor-mm.csv',['id','mitad','tipo','largo_ejes_mm','aX','aY','aZ','bX','bY','bZ','masa_kg'],[[m['id'],'A'if m['side']<0 else'B',m.get('kind','15x15x1'),m['L_mm'],*([m['a'][0]*1000,m['a'][2]*1000,(m['a'][1]-DAT)*1000]),*([m['b'][0]*1000,m['b'][2]*1000,(m['b'][1]-DAT)*1000]),m['mass_kg']]for m in data['members']])
AUDIT={'revision':'R07','sheets':6,'sheet_mm':[2440,1220],'parts':len(BLANK),'min_gap_mm':minimum,'min_margin_mm':min(min(q.bounds[0],q.bounds[1],2440-q.bounds[2],1220-q.bounds[3])for ss in occupied for _,q in ss),'pp_area_blanks_m2':pparea,'mass_kg':MASS,'margin_kg':MARGIN,'max_pp_gsm_to14_if_other_caps_unchanged':600+MARGIN/pparea*1000,'model_not_weighed':True,'placements':placements,'budget':BUDGET}
(OUT/'source/model-r07.json').write_text(json.dumps(clean(data),ensure_ascii=False,separators=(',',':')));(OUT/'source/manufacturing-r07.json').write_text(json.dumps(clean({'audit':AUDIT,'outlines':{c:rings(g)for c,g in BLANK.items()},'records':recs}),ensure_ascii=False,separators=(',',':')));(OUT/'source/verificacion-r07.json').write_text(json.dumps(clean(AUDIT),indent=2,ensure_ascii=False))
print('AUDIT',clean({k:v for k,v in AUDIT.items()if k not in ['placements','budget']}),flush=True)
