exec((__import__('pathlib').Path('tmp/pdfs/barco-r07/build.py').read_text()).split('# Ribs are net frames')[0]) if False else None
import json,math,csv,sys,shutil,hashlib,zipfile
from pathlib import Path
sys.path.insert(0,'/private/tmp/barco-libs')
import numpy as np
from shapely.geometry import Polygon
from shapely import affinity
ROOT=Path.cwd();OUT=ROOT/'output/blueprints-barco-r07';M=json.loads((OUT/'source/manufacturing-r07.json').read_text());A=M['audit'];D=json.loads((OUT/'source/model-r07.json').read_text());lookup={c:(s,a,xy)for c,s,a,xy in A['placements']}
def transform(pts,angle,xy,outline):
 a=math.radians(angle);r=np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]]);o=np.array(outline)@r.T;return np.array(pts)@r.T-o.min(axis=0)+xy

def dxf(path,records):
 out=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$INSUNITS','70','4','9','$MEASUREMENT','70','1','0','ENDSEC','0','SECTION','2','ENTITIES']
 for layer,pts,closed in records:
  if len(pts)<2:continue
  out+=['0','LWPOLYLINE','8',layer,'90',str(len(pts)),'70',str(int(closed))]
  for p in pts:out+=['10',f'{p[0]:.5f}','20',f'{p[1]:.5f}']
 out+=['0','ENDSEC','0','EOF'];path.write_text('\n'.join(out)+'\n')
for code,records in M['records'].items():
 dxf(OUT/'cad'/f'{code}-mm.dxf',records)
 g=Polygon(M['outlines'][code][0]);x0,y0,x1,y1=g.bounds;w=x1-x0+100;h=y1-y0+100
 ss=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="#073c75"/><g fill="none" stroke="white" stroke-width=".35">']
 for layer,pts,closed in records:
  if len(pts)<2:continue
  xy=' '.join(f'{x-x0+50:.4f},{h-(y-y0+50):.4f}'for x,y in pts);typ='polygon'if closed else'polyline';dash=''if layer=='CORTE'else' stroke-dasharray="5 3"';ss.append(f'<{typ} points="{xy}"{dash}><title>{layer}</title></{typ}>')
 ss.append(f'</g><text x="50" y="25" fill="white" font-family="sans-serif" font-size="12">{code} · R07 · mm 1:1 · sin compensar herramienta</text><path d="M50,{h-20}h100" stroke="white"/><text x="50" y="{h-26}" fill="white" font-size="10">Control 100 mm</text></svg>');(OUT/'plantillas'/f'{code}-1a1.svg').write_text('\n'.join(ss))
for si in range(6):
 ss=['<svg xmlns="http://www.w3.org/2000/svg" width="2440mm" height="1220mm" viewBox="0 0 2440 1220"><rect width="100%" height="100%" fill="#073c75"/>'];dr=[]
 for c,s,a,xy in A['placements']:
  if s!=si:continue
  outline=M['outlines'][c][0]
  for layer,pts,closed in M['records'][c]:
   if len(pts)<2:continue
   q=transform(pts,a,xy,outline);dr.append((layer,q,closed));typ='polygon'if closed else'polyline';ss.append(f'<{typ} points="'+ ' '.join(f'{x:.3f},{1220-y:.3f}'for x,y in q)+f'" fill="none" stroke="white" stroke-width=".4"'+(' stroke-dasharray="5 3"'if layer!='CORTE'else'')+'/>')
  q=transform(outline,a,xy,outline);x,y=q.mean(axis=0);ss.append(f'<text x="{x}" y="{1220-y}" font-family="sans-serif" font-size="12" text-anchor="middle" fill="white">{c}</text>')
 ss.append('</svg>');(OUT/'plantillas'/f'S{si+1:02}-2440x1220.svg').write_text('\n'.join(ss));dxf(OUT/'cad'/f'S{si+1:02}-2440x1220-mm.dxf',dr)
# Preserve applicable R06 fabrication detail tables and metal drawings, explicitly named reference.
for n in ['cunas-y-fijaciones-barras-mm.csv','agarres-y-anclajes-mm.csv','pasos-auxiliares-casco-mm.csv','recortes-auxiliares-por-pieza.csv','materiales-agarres-acolchados.csv']:
 src=ROOT/'output/blueprints-barco-r06/tablas'/n
 if src.exists():shutil.copy2(src,OUT/'tablas'/n)
print('CAD/SVG',len(M['records']),'pieces + 6 sheets')
