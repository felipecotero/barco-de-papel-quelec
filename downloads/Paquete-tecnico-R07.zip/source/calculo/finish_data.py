import sys,json,math,csv
from pathlib import Path
sys.path.insert(0,'/private/tmp/barco-libs')
import numpy as np
from shapely.geometry import Polygon,LineString,Point,box
from shapely.ops import unary_union,split
ROOT=Path.cwd();OUT=ROOT/'output/blueprints-barco-r07';mp=OUT/'source/manufacturing-r07.json';dp=OUT/'source/model-r07.json';M=json.loads(mp.read_text());D=json.loads(dp.read_text());A=M['audit'];parts={p['id']:p for p in D['parts']};FY=D['floorY'];Z0=D['datum'];S=np.array(D['seam']);fas=[]
def rings(g):return [list(g.exterior.coords)[:-1],*[list(r.coords)[:-1]for r in g.interiors]]
def polys(g):return [g]if g.geom_type=='Polygon'else[a for a in g.geoms if a.geom_type=='Polygon'and a.area>.001]
def world(uv,d):
 u,v=np.array(uv)/1000;return np.array(d['C'])+np.array(d['A'])*v+np.array(d['Eminus']if u<0 else d['Eplus'])*abs(u)
def flat(P,d):
 r=np.array(P)-d['C'];v=np.dot(r,d['A']);return [np.sign(P[0])*np.linalg.norm(r-v*np.array(d['A']))*1000,v*1000]
def setgeo(p,g):
 p['whole']=[rings(a)for a in polys(g)];secs=polys(g)
 for l in p['seams']:
  if len(l)<2:continue
  pts=np.array(l);pts[0]+=(pts[0]-pts[1])/np.linalg.norm(pts[0]-pts[1])*100;pts[-1]+=(pts[-1]-pts[-2])/np.linalg.norm(pts[-1]-pts[-2])*100
  try:secs=sum([polys(split(a,LineString(pts)))for a in secs],[])
  except ValueError:pass
 p['chunks']=[]
 for a in secs:
  P=world(a.representative_point().coords[0],p['development']);ds=(S[:,1]-P[1])**2+(S[:,2]-P[2])**2;ww=1/(.0001+ds)**2;cx=np.dot(S[:,0],ww)/sum(ww);p['chunks'].append({'side':-1 if P[0]<cx else 1,'rings':rings(a)})
 M['records'][p['id']]=[r for r in M['records'][p['id']]if r[0]!='CORTE']+[('CORTE',r,True)for a in polys(g)for r in rings(a)]
# Two rows per band. Long front joint:5+5 per half; back:4+4. Total36 new kits.
for code,p in parts.items():
 if not code.startswith('JV'):continue
 d=p['development'];g=Polygon(p['whole'][0][0]);# its four-sided nominal long band
 ext=np.array(M['outlines'][code][0]);# find long-axis from principal component
 vals,vecs=np.linalg.eigh(np.cov(ext.T));u=vecs[:,np.argmax(vals)];u*=1 if u[0]>0 else-1;v=np.array([-u[1],u[0]]);proj=ext@u;lo,hi=min(proj),max(proj);mid=float(np.mean(ext@v));L=hi-lo;n=5 if code.startswith('JV1')else 4;step=(L-120)/(n-1)
 for row in [-1,1]:
  for i in range(n):
   q=u*(lo+60+i*step)+v*(mid+row*15);hole=Point(q).buffer(3.1,resolution=24);assert g.covers(hole),(code,q)
   skin=next((r for r in parts.values()if r['id'].startswith('V0'+code[2]) and Polygon(r['uv']).covers(hole)),None);assert skin is not None,(code,q)
   P=world(q,d);fas.append({'id':f'{code}-{row}-{i+1}','parent':skin['id'][:3],'piece':skin['id'],'band':code,'panel_uv':q.tolist(),'piece_uv':q.tolist(),'band_uv':q.tolist(),'world_mm':[P[0]*1000,P[2]*1000,(P[1]-Z0)*1000],'step':step})
   for target in [p,skin]:
    gg=unary_union([Polygon(r[0],r[1:])for r in target['whole']]).difference(hole);setgeo(target,gg)
assert len(fas)==36;D['fasteners']+=fas
# Crossmember neck connects to each principal-bar hole; avoids a thin strip below the circle.
for p in parts.values():
 if not p['id'].startswith('V'):continue
 d=p['development'];g=unary_union([Polygon(r[0],r[1:])for r in p['whole']])
 for b in D['bars']:
  # Interpolate onto the planar facet at each XY corner.
  pts=[]
  for x,y in [(b['x']-.0081,b['y']-.0446),(b['x']+.0081,b['y']-.0446),(b['x']+.0081,b['y']),(b['x']-.0081,b['y'])]:
   E=np.array(d['Eminus']if x<0 else d['Eplus']);C=np.array(d['C']);av=np.array(d['A']);u=abs(x/E[0]);vv=(y-C[1]-E[1]*u)/av[1];P=C+E*u+av*vv;pts.append(flat(P,d))
  g=g.difference(Polygon(pts))
 # All four front skin plates now fix one wall only, with two holes normal to that wall.
 if p['id'].startswith('V01'):
  for an in [a for a in D['anchors']if a['kind']=='vela']:
   P=np.array([an['center'][0]/1000,an['center'][2]/1000+Z0,an['center'][1]/1000]);q=np.array(flat(P,d))
   for dv in [-15,15]:
    hole=Point(q+[0,dv]).buffer(3.1,resolution=24)
    if Polygon(p['uv']).covers(hole):g=g.difference(hole)
 setgeo(p,g)
# B spine runs within the rib plane; provide an open slot instead of overlapping solids.
rr=M['outlines']['CB'];g=Polygon(rr[0],rr[1:]).difference(box(-8.6,-1,8.6,(1.11-FY)*1000+8.6));M['outlines']['CB']=rings(g);M['records']['CB']=[('CORTE',r,True)for r in rings(g)]
# Explicit round holes in every auxiliary blank; layout does not change.
for code in M['outlines']:
 if code.startswith(('TP','VC')):
  M['records'][code]=[r for r in M['records'][code]if not r[0].startswith('TALADRO')]
  for xx in [15,45,75,105]:M['records'][code].append(('TALADRO_6_2',[(xx+3.1*math.cos(a),15+3.1*math.sin(a))for a in np.linspace(0,2*math.pi,49)[:-1]],True))
# Store extras so viewer, sheets and CAD share precisely the same net rib.
D['ppExtras']={c:r for c,r in M['outlines'].items()if c not in parts};D['massBudget']=A['budget'];D['nesting']=A['placements'];D['stockAudit']={k:A[k]for k in ['sheets','sheet_mm','parts','min_gap_mm','min_margin_mm','pp_area_blanks_m2']};D['ribMounting']='U metálica a raíl, M4 transversal con casquillo15; sin atravesar cara inferior del fondo';D['referenceRevision']='R06';D['formStudy']['totalNylonBandKits']=92
# Assembly locator table for six closure pairs, nominal positions; all lie on the original scenic field.
closures=[]
def cut(y,z):
 ds=(S[:,1]-y)**2+(S[:,2]-z)**2;a=1/(.0001+ds)**2;return float(np.dot(S[:,0],a)/sum(a))
k=(.135-.004)/(1-(.9375*.135-FY)/(2-FY));
for y,zz in [(.340,.340/.9375),(.520,None),(1.140,None)]:
 for sg in [-1,1]:
  z=sg*(zz if zz is not None else k*(1-(y-FY)/(2-FY)));x=cut(y,z)
  if zz is None:
   for _ in range(10):z=sg*k*max(0,1-(y-FY)/(2-FY)-abs(x)/.9983505);x=cut(y,z)
  closures.append([f'C{len(closures)+1}',x*1000,z*1000,(y-Z0)*1000,20,15])
D['closures']=closures
with (OUT/'tablas/cierres-velcro-mm.csv').open('w')as f:w=csv.writer(f);w.writerow(['id','X_mm','Y_mm','Z_mm','contacto_alto_mm','contacto_fondo_mm']);w.writerows(closures)
with (OUT/'tablas/juntas-vela-fijaciones.csv').open('w')as f:w=csv.writer(f);w.writerow(['id','panel','banda','u_mm','v_mm','X','Y','Z','paso_mm']);w.writerows([[a['id'],a['piece'],a['band'],*a['piece_uv'],*a['world_mm'],a['step']]for a in fas])
with (OUT/'tablas/auxiliares-PP-y-fijacion.csv').open('w')as f:
 w=csv.writer(f);w.writerow(['grupo','cantidad','blanco_mm','taladro_y_pliegue','funcion']);w.writerows([['TP01-TP12',12,'120x30x4','u15/45/75/105;v15;Ø6.2;pliegueu60','2 por arista: A-K,B-J,F-K,F-J,R-K,R-J; a1/3y2/3 de tramo visible'],['TP13-TP16',4,'120x30x4','solo ala casco atornillada; ala fondo adhesivo LSE','fondo X±650,Y±104.94; sin taladrar cara inferior'],['TP17-TP24',8,'120x30x4','dos fijaciones por ala; presentar al ángulo real','costillas X±280 aZ280/720 desde su base; una por cada cara'],['TP25-TP28',4,'120x30x4','PP aU metálica; no al fondo por debajo','2 por costilla sobre raíles; M4metalcasquillo15'],['VC01-VC12',12,'120x30x4','pieM4x20;retornoM4x12+pletina;funda cosida','una por lado de cada cierreC1..C6'],['CP01-CP68',68,'60x30x4','u15/45;v15;Ø6.2','reparto: 56 paraTP,12 paraVC; sobrantes del fondo como reserva']])
D['parts']=list(parts.values());dp.write_text(json.dumps(D,ensure_ascii=False,separators=(',',':')));mp.write_text(json.dumps(M,ensure_ascii=False,separators=(',',':')))
print('R07 details:36 nuevos kits de banda;92 total;133 piezasPP; rótulos y taladros incluidos')
