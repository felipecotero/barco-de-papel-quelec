import sys,json,math,csv,re
from pathlib import Path
sys.path.insert(0,'/private/tmp/barco-libs')
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor,white
from reportlab.lib.utils import simpleSplit
from reportlab.lib.units import mm
ROOT=Path.cwd();OUT=ROOT/'output/blueprints-barco-r07';M=json.loads((OUT/'source/manufacturing-r07.json').read_text());A=M['audit'];D=json.loads((OUT/'source/model-r07.json').read_text());FY=D['floorY'];Z0=D['datum'];PDF=ROOT/'output/pdf/Barco-papel-Blueprints-R07-7-pliegos-100x70.pdf'
fonts=Path('/Users/felipecamachootero/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype')
for n,f in [('S','DejaVuSans.ttf'),('B','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,str(fonts/f)))
c=canvas.Canvas(str(PDF),pagesize=(1000*mm,700*mm));c.setTitle('Barco de papel R07 - 7 pliegos - vela270 - seis láminas - máximo15kg');c.setAuthor('Quelec / Taller de construcción');P=0

def line(a,b,w=.3,dash=None):
 c.setStrokeColor(white);c.setLineWidth(w*mm);c.setDash(dash or[]);c.line(a[0]*mm,a[1]*mm,b[0]*mm,b[1]*mm);c.setDash([])
def poly(pts,closed=True,w=.3):
 if len(pts)<2:return
 c.setStrokeColor(white);c.setLineWidth(w*mm);p=c.beginPath();p.moveTo(pts[0][0]*mm,pts[0][1]*mm)
 for x,y in pts[1:]:p.lineTo(x*mm,y*mm)
 if closed:p.close()
 c.drawPath(p)
def spaced(s):
 s=str(s);s=re.sub(r'(?<=\d)(?=(?:mm|kg|g/m|g\b))',' ',s);s=re.sub(r'(?<=[a-záéíóú])(?=[A-ZØ0-9])',' ',s);s=re.sub(r'(?<=[:;])(?=[A-Za-z0-9])',' ',s);return s
def txt(x,y,s,size=20,b=False):
 s=spaced(s)
 c.setFillColor(white);c.setFont('B'if b else'S',size);c.drawString(x*mm,y*mm,str(s))
def para(x,y,w,s,size=21):
 for ls in spaced(s).split('\n'):
  for t in simpleSplit(ls,'S',size,w*mm):txt(x,y,t,size);y-=size*.3528*1.38
  y-=2
 return y

def title(x,y,s):txt(x,y,s,26,True)
def page(title_,sub):
 global P
 if P:c.showPage()
 P+=1;c.setFillColor(HexColor('#073c75'));c.rect(0,0,1000*mm,700*mm,fill=1,stroke=0)
 c.setStrokeColor(HexColor('#1b4e83'));c.setLineWidth(.08*mm)
 for x in range(25,981,25):c.line(x*mm,55*mm,x*mm,630*mm)
 for y in range(55,631,25):c.line(20*mm,y*mm,980*mm,y*mm)
 txt(25,665,f'B-{P:02}  {title_}',32,True);para(25,645,950,sub,20);line((20,628),(980,628),.5);line((20,48),(980,48),.5)
 txt(25,30,'QUELEC / BARCO DE PAPEL / R07 / 22.10.2026',16,True);txt(25,20,'1000 x 700 mm · imprimir al100% · cotas nominales enmm · blanco sobre azul',16)
 txt(640,30,'M: geometría · P: solución propuesta · V: probar en taller',16);txt(850,20,f'{P}/7 · máximo terminado15kg',16,True)
 c.bookmarkPage('B'+str(P));c.addOutlineEntry(f'B-{P:02} {title_}','B'+str(P))
def table(x,y,w,heads,rows,widths=None,size=20):
 widths=widths or[1]*len(heads);total=sum(widths);ww=[w*v/total for v in widths];xs=np.r_[x,x+np.cumsum(ww)];line((x,y+5),(x+w,y+5))
 for j,h in enumerate(heads):txt(xs[j]+2,y-3,h,size,True)
 y-=15
 for row in rows:
  wraps=[simpleSplit(str(v),'S',size,(ww[j]-6)*mm)for j,v in enumerate(row)];hh=max(13,max(map(len,wraps))*size*.3528*1.24+5)
  for j,ls in enumerate(wraps):
   for k,t in enumerate(ls):txt(xs[j]+2,y-3-k*size*.3528*1.24,t,size)
  y-=hh;line((x,y+5),(x+w,y+5),.15)
 return y

def world(uv,p):
 if p.get('development'):
  d=p['development'];u,v=np.array(uv)/1000;return np.array(d['C'])+np.array(d['A'])*v+np.array(d['Eminus']if u<0 else d['Eplus'])*abs(u)
 return np.array(p['origin'])+np.array(p['u'])*uv[0]/1000+np.array(p['v'])*uv[1]/1000

def proj(p,view):
 x,y,z=p;y-=Z0
 return np.array([x,y]if view=='side'else[x,z]if view=='top'else[z,y]if view=='end'else[.8*x-.6*z,.25*x+.35*z+.85*y])*1000

def model(view,x,y,sc,sep=0,hardware=True,skins=True,onlyV=False):
 for p in D['parts'] if skins else []:
  if onlyV and not p['id'].startswith('V'):continue
  if p['id'].startswith('J'):continue
  for chunk in p['chunks']if sep else[{'side':0,'rings':a}for a in p['whole']]:
   pts=[]
   for uv in chunk['rings'][0]:
    P=world(uv,p);P[0]+=chunk['side']*sep/2;pts.append([x,y]+proj(P,view)*sc)
   poly(pts,True,.28)
 if hardware:
  for m in D['members']:
   aa=np.array(m['a']);bb=np.array(m['b']);aa[0]+=m['side']*sep/2;bb[0]+=m['side']*sep/2;line([x,y]+proj(aa,view)*sc,[x,y]+proj(bb,view)*sc,.45)
  for b in D['bars']:
   line([x,y]+proj([b['x']+b['side']*sep/2,b['y'],b['z0']],view)*sc,[x,y]+proj([b['x']+b['side']*sep/2,b['y'],b['z1']],view)*sc,.8)
def dim(a,b,label,dy=-10):
 line(a,b,.2);line((a[0],a[1]-3),(a[0],a[1]+3));line((b[0],b[1]-3),(b[0],b[1]+3));txt((a[0]+b[0])/2-15,(a[1]+b[1])/2+dy,label,20,True)
def block(x,y,w,h,head,body):title(x,y,head);return para(x,y-18,w,body)
# 1
page('CONJUNTO Y BALANCE DE PESO','Construir entero primero. Vela con cuatro caras y270mm. Cuatro adultos. Objetivo14kg; máximo autorizado15kg.')
title(35,602,'ALZADO / 1:8');model('side',285,338,.125,hardware=False);dim((35,328),(535,328),'4000')
title(35,285,'PLANTA / 1:8');model('top',285,170,.125,hardware=False);txt(35,65,'ANCHO1600',20,True)
title(565,602,'PRESUPUESTO COMPLETO / kg')
rows=[]
for name,v,typ in A['budget']:
 short=name.replace('Todo PP instalado: paños, bandas, costillas, 40 pestañas y 68 contraplacas','PP: todos los blancos y refuerzos').replace('Brazos casco, placas, apoyos y protección R06 / límite','Repartos, apoyos y brazos casco').replace('Perfiles 15x15x1 y auxiliares Ø16x1 calculados','Bastidores y auxiliares originales').replace('8 mangas y 8 remates blandos / límite','8 mangas +8 remates').replace('4 cunas completas / límite 150 g cada una','4 cunas completas').replace('Nuevos perfiles y brazos Al para vela y bandera','Al adicional: vela y bandera').replace('Nuevos kits nylon: bandas vela, pestañas y cierres','Kits nuevos: bandas, pestañas, cierres')
 rows.append([short,f'{v:.3f}'])
y=table(565,580,400,['Partida','kg'],rows,[4,1],18)
para(565,y-9,400,f'Total a600g/m²: {A["mass_kg"]:.3f}kg. A700g/m²: {A["mass_700gsm_kg"]:.3f}kg. Techo15kg; margen con700: {A["margin_700gsm_kg"]:.3f}kg. Límites de compra y masa instalada; no es pesaje.',20)
# 2
page('DESPIECE / SEIS LÁMINAS VERIFICADAS','Formato2440x1220x4mm.133 blancosPP:23 paños/bandas grandes y110 auxiliares. Margen10mm; separación mínima6mm.')
for si in range(6):
 x=30+(si%2)*485;y=447-(si//2)*184;sc=.126
 title(x,y+162,f'S{si+1:02} / 1:7,94');poly([[x,y],[x+2440*sc,y],[x+2440*sc,y+1220*sc],[x,y+1220*sc]])
 counts={}
 for code,ss,ang,xy in A['placements']:
  if ss!=si:continue
  o=np.array(M['outlines'][code][0]);r=math.radians(ang);rot=np.array([[math.cos(r),-math.sin(r)],[math.sin(r),math.cos(r)]]);q=o@rot.T;q=q-q.min(axis=0)+xy
  for ring in M['outlines'][code]:
   rr=np.array(ring)@rot.T;rr=rr-(o@rot.T).min(axis=0)+xy;poly(rr*sc+[x,y],True,.18)
  prefix='TP'if code.startswith('TP')else'VC'if code.startswith('VC')else'CP'if code.startswith('CP')else code;counts[prefix]=counts.get(prefix,0)+1
  if prefix not in ['TP','VC','CP']:
   p=q.mean(axis=0)*sc+[x,y];txt(p[0]-9,p[1],code,16,True)
 para(x+320,y+145,145,' / '.join(f'{k} x{v}'if v>1 else k for k,v in counts.items()),18)
para(30,66,940,'Los133 códigos y sus orígenes están en compra-y-anidado.csv. Los auxiliares sin rótulo individual se identifican allí. Cortar primero piezas anidadas dentro de ventanas y luego el perímetro de la costilla. DXF/SVG1:1 nominales: comprobar100mm, herramienta y dirección de alvéolos antes de mecanizar.',18)
# 3
page('ETAPA I / JUNTAS, PESTAÑAS Y PEGADO','Unir paños, formar volumen y montar todo antes del corte escénico. La cinta no sustituye las fijaciones.')
block(35,600,430,170,'BANDAS DE CASCO:60mm','J01-J04:30mm a cada lado. Dos filas a15mm del encuentro; extremos60; paso129,2167.7 posiciones por fila:56 kits M4x16 nylon. ArandelasØ18 por ambas caras; casquilloØ6/ID4,3/L8, ajustado a panel4+banda4. Mantener alivios auxiliares R06 en las cuatro bandas.')
# Section, exaggerated layers with dimensions
for yy,ww in [(380,220),(375,60)]:poly([[140-ww/2,yy],[140+ww/2,yy],[140+ww/2,yy+4],[140-ww/2,yy+4]])
for xx in [125,155]:line((xx,366),(xx,392),1);poly([[xx-9,385],[xx+9,385],[xx+9,387],[xx-9,387]])
dim((110,355),(170,355),'60',-12);txt(35,405,'SECCIÓN / espesores esquemáticos',20,True)
block(35,320,430,180,'BANDAS NUEVAS DE VELA','JV1L/JV1R en encuentro V01A/B;JV2L/JV2R enV02A/B.60mm, una por faceta, sin aplastar el pliegue.5 fijaciones por fila en cadaJV1 y4 en cadaJV2:36 kits. En total92 kits de bandas. Coordenadas y pasos exactos en juntas-vela-fijaciones.csv. Taladrar paño y banda juntos.')
block(35,167,430,100,'GAFFER Y FONDO PLANO','Gaffer50mm para presentar, cubrir cantos y acabado. No cruzar el corte repetible. FondoB01: sin tornillos sobresaliendo por debajo; alas TP13-16 pegadas al PP con adhesivoLSE compatible y probado.')
block(530,600,430,100,'PESTAÑA TP / VC:120x30x4','Pliegue a60. TaladrosØ6,2 enu15/45/75/105,v15. Dos por ala. Contraplaca CP60x30x4, taladrosu15/45,v15. Centros a15mm de todo borde. No usar autorroscantes ni apretar hasta hundir las celdas.')
for x0 in [560,710]:
 poly([[x0,430],[x0+120,430],[x0+120,460],[x0,460]]);line((x0+60,430),(x0+60,460),.25,[3,2])
 for dx in [15,45,75,105]:c.circle((x0+dx)*mm,445*mm,3.1*mm)
dim((560,415),(680,415),'120');dim((710,415),(770,415),'60')
block(530,365,430,140,'UBICACIONES Y FIJACIÓN','TP01-12: dos en cada arista visible A-K,B-J,F-K,F-J,R-K,R-J, a1/3 y2/3 del tramo; ajustar ángulo. TP13-16: fondo enX±650,Y±104,94. TP17-24: costillas a280/720mm de su base, una por cara y altura. TP25-28: costillas a raíles, con Umetálica. M4 nylon x20 para tres capasPP, casquillo12 nominal; x16 para doscapas, casquillo8. Ajustar pila real.')
block(530,196,430,120,'ADHESIVO ESPECÍFICO PARA PP','PropuestaDP8005 o equivalente LSE con ficha paraPP. Aplicar y curar según ficha vigente; probar con las láminas compradas.60g instalados incluidos. No dar por válida una cinta genérica sobrePP. Fuente:3M DP8005; ver enlaces del README. Las pestañas del fondo se pegan para conservar su cara inferior lisa.')
# 4
page('ETAPA I / BASTIDORES, BARRAS Y AGARRES','A conservaR02; B conservaR01. Nunca cortar barras, perfiles, costillas ni soporteT01 al abrir las mitades.')
title(35,602,'DOS BASTIDORES / PLANTA / 1:7,14');model('top',270,465,.14,hardware=True,skins=False)
block(35,325,430,130,'PERFILES Y NUEVOS APOYOS','Conservar24 tramos15x15x1 y8 auxiliaresØ16x1 R06. Montantes P10/P12 ahora enY=0 para quedar dentro de la vela hueca. Cuatro brazosL20x20x1,5 alcanzan placas de una sola piel: casquillo5,5 yM4x16; no atravesar el hueco con un casquillo9,5. Longitudes entre ejes en CSV, no largos finales de sierra.')
block(35,175,430,100,'COSTILLAS AL BASTIDOR','Dos Ualuminio por costilla, sobre raíles enX±280. Uclaro15,2; pared2; apoyo30. DosM4x30 metálicos transversales con casquilloOD6/ID4,3/L15 dentro del perfil. AlaPP aU con M4nylon y reparto. No perforar el fondo por debajo.120g para cuatro conjuntos completos.')
block(530,602,430,160,'CUATRO CUNAS / R06 CONSERVADAS','Dos por barra, Y±200:400 entre ejes. Cuerpo partidoPA6-GF30, nominalID40/OD48/ancho30; placaAl90x45x3 desplazada7,5 hacia dentro; Uclaro15,2. DosM6x45 por cuna aX±32 del eje de barra, separadoresAlOD10/ID6,5/L18. DosM4x30 al perfil, casquilloL15; collarín a cada lado.150g máximo por conjunto completo. Ajuste, apriete y antigiro por probeta.')
block(530,408,430,160,'PRINCIPAL Y AUXILIAR ACOLCHADOS','Barras principalesAlØ40x2: R01=1685,78;R02=1585,30. No se adelgazan. AuxiliaresØ16x1, avance188 hacia su punta;65 arriba del eje; raícesY±140, extremo metalY±555 yacolchado±570. Raíz ajustada en silla yTIG, dos cartelas30x25x1,5 por raíz.24cartelas40x40 más8pequeñas; cartelas yTIG<=200g. No asumir resistenciaT6 intacta tras soldar.')
block(530,201,430,110,'CONTACTO CON LAS MANOS','Ocho mangas120mm útiles, EVA/EPDM antideslizante: principalOD44, auxiliarOD30. Ocho remates blandos cerrados y retenidos; conjunto<=88g. Espigas paraID36/14, inserción20 nominal. Comprobar giro, deslizamiento y extracción; ambas manos pueden soltar libremente.')
# 5
page('ETAPA I / VELA270, COSTILLAS Y BANDERA','Cuatro facetas, una pielPP4 por costado plegada por su arista. Los desarrollos son reales, no proyecciones planas.')
title(35,602,'VELA / ALZADO / 1:8');model('side',185,317,.125,hardware=False,onlyV=True)
block(35,266,290,175,'FORMA Y CIERRE','V01A/B yV02A/B: cortar y plegar por la línea central marcada. JuntasV01 enZ905,62;V02 enZ1105,62. Profundidad exterior máxima270; el faldón se recorta al casco inclinado, sin ensanchar el fondo209,88. Altura desde cara inferior del piso1905,62. Unir base al casco con sus pestañas; no dejar caras sueltas.')
title(365,602,'COSTILLA / 1:3,5')
r=M['outlines']['CA']
for rr in r:poly(np.array(rr)*.2857+[425,190],True,.35)
dim((425-191.35/2*.2857,175),(425+191.35/2*.2857,175),'191,35')
block(350,150,270,80,'CA / CB:PP4','X±280. Alto1368,29; marco40. Muescas libran perfiles; CB lleva canal para la espina de bandera. Una por mitad; no cruza el corte.')
block(655,602,310,140,'T01 / TODO EN B','AlØ32x1, ID30, largo1603,32. X85,51;Y-5,07;Z317,87 a1921,19. Sustituye tubo anterior de masa supuesta. Masa calculada0,422kg. Paso nominalØ32,5 donde el cilindro intersecta la piel. No abrir una ranura por toda la vela.')
block(655,428,310,160,'ESPINA Y DOS BRAZOS','EspinaB-P18 Al15x15x1 enX280,Y0, desdeZ11,50 a1015,62; traviesaB-P17 de122. Dos brazosL20x20x1,5 aZ455,62 y1005,62 hastaT01. Dos abrazaderas al tubo, sin aplastarlo;80g para abrazaderas y tornillos. Unir a bastidorB antes delPP, no colgar la bandera de la piel.')
block(655,224,310,135,'ASTA DESMONTABLE','AstaØ21x930; inserción250, salida680. Dos guías PP/PA ID22/OD30/L20, ajuste al tubo real. Collar de tope y retención desmontable enB; redondear extremos. Bandera480x320, vuelo440. Asta, bandera y guías<=300g. Altura final con bandera supera la vela.')
# 6
page('ETAPA II / CORTE Y CIERRE CON VELCRO','Cortar solo después de montar, curar, pesar y comprobar todo el barco. Rearme repetible sin herramientas en escena.')
title(35,602,'CIERRE / SECCIÓN ESQUEMÁTICA');
for xx,sg in [(175,-1),(195,1)]:
 line((xx+sg*75,550),(xx,550),1);line((xx,550),(xx,580),1);line((xx-sg*3,558),(xx-sg*3,573),2)
txt(35,580,'Pie60x30',20);txt(220,570,'Gancho / bucle20x15',20);txt(35,520,'SEPARACIÓN / AXONOMETRÍA / S.E.',22,True);model('iso',270,355,.085,sep=.70,hardware=True)
block(35,270,440,165,'CORTE ESCÉNICO','Transferir la curva de CORTE_ESCENICO a piel, fondo y todas las bandas que atraviese. La vela usa la misma función de corte sobre sus nuevas caras; no copiar la traza plana R06. Cortar apoyado en taller, una sola vez. Cada costilla, barra y bastidor permanece entero. Numerar parejas antes de separar; cortar gaffer y acabado por la misma traza.')
block(35,110,440,65,'REARME','Encajar sin forzar y presionar los contactos. Los antiguos imanes no se añaden. Sin correas o pestillos que obliguen a soltar una mano.')
title(530,602,'C1-C6 / COORDENADAS NOMINALES')
table(530,578,435,['ID','X','Y','Z'],[[r[0],*[f'{v:.1f}'for v in r[1:4]]]for r in D['closures']],[.8,1,1,1],21)
block(530,430,435,160,'VC:UNA PIEZA POR CADA LADO','Doce soportesVC120x30x4, plegadosa60. Pie60x30 conCP60x30 ydosM4x20nylon, Ø18 ycasquillo12. Retorno60x30: funda de velcro para coser, cosida a sí misma alrededor del PP; pletina de apriete ydosM4x12 mantienen la funda. No coser a través delPP. Adaptar borde de cada soporte a la curva real sin invadir la otra mitad.')
block(530,227,435,140,'CONTACTO20x15 / ENSAYAR APERTURA','Seis parejas de gancho/bucle, área máxima inicial20x15 cada una, reducible con máscara. Los retornos se enfrentan normal aX y se abren al separar las mitades, sin accionamiento manual. Medir fuerza y tirón, desgaste, ruido y repetición; ajustar área antes del uso elevado. El velcro alinea: no recibe el peso de la otra mitad.')
# 7
page('MONTAJE, ACEPTACIÓN Y COMPRA','Secuencia de taller y control de masa.15kg de techo;14kg como objetivo. No certificar cargas por dividir el peso entre cuatro.')
y=602
steps=[('1 / COMPRAR Y MARCAR','Seis2440x1220x4. Objetivo600g/m²; admisible hasta700g/m² solo con los demás límites de esta revisión. Pesar una muestra de área conocida. Marcar alvéolos y códigos.'),('2 / CORTAR Y PROBAR','133blancos. Recortar interiores antes de liberar perímetros; revisar control100mm, muescas y holguras. Probar PP, nylon, adhesivo y retorno de velcro con materiales reales.'),('3 / BASTIDORES','Soldar perfiles, cartelas y brazos. Montar cunas, barras, collarines, auxiliares y espinaB. Verificar independencia, alineación y retención antes de cerrar piel.'),('4 / CASCO Y VELA ENTEROS','Montar juntas a tope, bandas y pestañas; pliegues de vela, costillas, apoyos al bastidor, fondo y piel. Respetar el curadoLSE. T01 yasta íntegros enB.'),('5 / ACABADO Y PESAJE','Mangas, remates, gaffer y acabado dentro de sus límites. Pesar objeto completo con asta y bandera, cada mitad y cada puesto de manos. Registrar masa y equilibrio.'),('6 / CORTAR Y REARMAR','Corte único sobre piel, fondo, bandas y acabado; conservar estructuras. InstalarC1-C6 y comprobar reunión sin tensión. Ajustar fuerza con ensayo apoyado.'),('7 / VALIDAR CON INTÉRPRETES','Cuatro adultos, dos por mitad; agarre principal y auxiliar en espejo. Ensayar elevar, sostener, separar y volver a unir. No liberar fijaciones de carga en escena.')]
for h,t in steps:
 txt(35,y,h,23,True);y=para(35,y-13,440,t,20)-10
block(535,602,430,150,'CONDICIÓN DE PESO',f'Presupuesto a600g/m²: {A["mass_kg"]:.3f}kg.\nA700g/m²: {A["mass_700gsm_kg"]:.3f}kg.\nMargen hasta15 con700: {A["margin_700gsm_kg"]:.3f}kg.\nTodo el PP instalado: {A["pp_area_blanks_m2"]:.3f}m² nominales. No descontar agujeros ni desperdicios para justificar un exceso de herrajes.')
block(535,408,430,135,'CUATRO PORTADORES','A15kg:3,75kg por adulto de media. En el escenario700:3,69kg de media. Estimación por mitad con700: A6,86kg; B7,91kg. Dos adultos por mitad:3,43 y3,96kg de media. Las reservas se reparten al50%. Son referencias aritméticas, no fuerzas máximas: bandera enB, posiciones, movimientos y apertura alteran el reparto. Comprobar cada mitad y cada puesto con el prototipo; no asumir reparto25% idéntico.')
block(535,235,430,140,'ACEPTACIÓN Y DOCUMENTOS','Masa real<=15kg; fondo inferior plano; costillas y bastidores independientes; manos libres; ninguna punta o canto expuesto; mangas y tapones retenidos; cierre repetible sin tirón excesivo. Guías y cierres no sostienen una mitad desde la otra. Plantillas, tablas, presupuesto, verificación y fuentes en el paqueteR07. UnionesTIG, PP y maniobra requieren revisión del constructor y prueba física.')
c.save();print(PDF)
